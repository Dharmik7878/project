from django.apps import AppConfig


class ExportDypConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'export_dyp'
