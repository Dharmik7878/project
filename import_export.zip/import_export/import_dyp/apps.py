from django.apps import AppConfig


class ImportDypConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'import_dyp'
